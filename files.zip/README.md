# Horoscope App

This is a React Native app that allows users to check their horoscopes by scanning their fingerprint. The app also includes a form to input personal information (name, surname, birthdate) and calculates the user's zodiac sign.

## Features

- Fingerprint scanning to display random horoscope messages.
- Dark mode and light mode themes.
- Form validation for user information.
- Zodiac sign calculation based on birthdate.
- Animated modal to display horoscope messages.
- Progress bar to indicate the scanning process.
- Play a mystical sound when scanning the fingerprint.

## Installation

1. Clone the repository:
   ```sh
   git clone https://github.com/yourusername/horoscope-app.git
   cd horoscope-app